module.exports = {
  'Name': '姓名',
}
