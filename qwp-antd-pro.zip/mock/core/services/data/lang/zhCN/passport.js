module.exports = {
  'New password': '新密码',
  'Change your password': '设置新密码',
  'Password confirmation': '密码确认',
  'New password is required': '新密码必须填写',
  'Password confirmation is required': '密码确认必须填写',
}
