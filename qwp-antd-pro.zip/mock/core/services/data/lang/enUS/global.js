module.exports = {
  ok: 'Ok',
  cancel: 'Cancel',
  clearNotice: '{0} are cleared',
}
