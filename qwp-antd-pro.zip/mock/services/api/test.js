export default {
  get: {
    _: 'bbb',
    $: {
      delete: 'ccc'
    }
  },
  post: {
    _: 'ccc',
    $: {
      update: 'ddd'
    }
  },
};

