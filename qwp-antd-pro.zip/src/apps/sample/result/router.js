var router = {
  icon: 'check-circle-o',
  items: [{
    path: 'fail',
    code: 'error',
  }, 'success', ],
};
