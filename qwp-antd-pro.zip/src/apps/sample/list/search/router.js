var router = {
  models: 'list',
  items: ['applications', 'articles', 'projects',],
};
