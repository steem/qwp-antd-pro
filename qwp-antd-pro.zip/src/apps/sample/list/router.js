var router = {
  icon: 'table',
  models: 'list',
  items: [{
    path: 'table',
    selfModels: 'rule',
  }, 'basic', 'card', ],
};
