var router = {
  icon: 'profile',
  models: 'profile',
  items: ['advanced', 'basic', 
    { path: 'books', selfModels: 'books' }
  ],
};
