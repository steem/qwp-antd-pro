var router = {
  icon: 'form',
  models: 'form',
  items: [{
    path: 'basic-form',
    code: 'BasicForm',
  },
  'step-form', {
    path: 'advanced-form',
    code: 'AdvancedForm',
  }],
};
