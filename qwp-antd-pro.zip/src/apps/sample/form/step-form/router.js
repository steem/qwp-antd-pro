var router = {
  models: 'form',
  page: true,
  items:[{
    path: 'info',
    code: 'Step1',
  },{
    path: 'confirm',
    code: 'Step2',
  },{
    path: 'result',
    code: 'Step3',
  }]
};
