var router = {
  icon: 'dashboard',
  items: [{
    models: ['project', 'activities', 'chart'],
    path: 'workplace',
  },{
    models: ['monitor'],
    path: 'monitor',
  }],
};
