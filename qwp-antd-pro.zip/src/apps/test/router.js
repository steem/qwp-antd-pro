var router = {
  public: true,
  icon: 'file',
  items: {}
};
