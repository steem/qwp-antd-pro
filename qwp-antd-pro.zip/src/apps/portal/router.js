var router = {
  public: true,
  items: {
    models: 'chart',
  },
};
