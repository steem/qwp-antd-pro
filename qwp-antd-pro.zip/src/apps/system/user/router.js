var router = {
  items: [{
    path: 'users',
    models: 'users',
    icon: 'user',
  },{
    path: 'role',
    models: 'role',
  }],
};
