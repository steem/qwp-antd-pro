var router = {
  icon: 'setting',
  items: [{
    path: 'basic',
    models: 'basic',
  },{
    path: 'features',
    models: 'features',
  }],
};
