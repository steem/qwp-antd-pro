<?php
if(!defined('QWP_ROOT')){exit('Invalid Request');}