import React from 'react';
import './page.less';

class Page extends React.Component {
  render() {
    return (<div id="page" />);
  }
}

export default Page;
